import joblib
import os
import numpy as np
from django.shortcuts import render

# Load the model from the correct path
model_path = os.path.join(os.path.dirname(__file__), "iris_predictive_model.pkl")
model = joblib.load(model_path)

def predict_species(request):
    if request.method == 'POST':
        try:
            sepal_length = float(request.POST.get('sepal_length', 0))
            sepal_width = float(request.POST.get('sepal_width', 0))
            petal_length = float(request.POST.get('petal_length', 0))
            petal_width = float(request.POST.get('petal_width', 0))

            # Make a prediction
            prediction = model.predict([[sepal_length, sepal_width, petal_length, petal_width]])
            predicted_class = prediction[0]

            return render(request, 'result.html', {'prediction': predicted_class})
        except Exception as e:
            return render(request, 'result.html', {'error': f"Error: {str(e)}"})

    return render(request, 'index.html')
